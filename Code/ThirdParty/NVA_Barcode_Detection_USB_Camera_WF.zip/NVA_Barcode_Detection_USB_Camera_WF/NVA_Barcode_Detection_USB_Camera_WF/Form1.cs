﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Ozeki.Media.MediaHandlers;
using Ozeki.Media.MediaHandlers.Video;
using Ozeki.Media.MediaHandlers.Video.CV;
using Ozeki.Media.MediaHandlers.Video.CV.BarcodeData;
using Ozeki.Media.MediaHandlers.Video.CV.Processer;
using DateTime = System.DateTime;

namespace NVA_Barcode_Detection_USB_Camera_WF
{
    public partial class BarcodeForm : Form
    {
        private IBarcodeReader _barcodeReader;
        private WebCamera _webCamera;
        private DrawingImageProvider _imageProvider;
        private MediaConnector _connector;
        private ImageProcesserHandler _imageProcesserHandler;
        private FrameCapture _frameCapture;
        private List<DetectedBarcode> _barcodesList;
        private int _counter;

        public BarcodeForm()
        {
            InitializeComponent();
        }

        void BarcodeForm_Load(object sender, EventArgs e)
        {
            _imageProvider = new DrawingImageProvider();
            _connector = new MediaConnector();
            _imageProcesserHandler = new ImageProcesserHandler();
            _frameCapture = new FrameCapture();
            _barcodeReader = ImageProcesserFactory.CreateBarcodeReader();
            _barcodesList = new List<DetectedBarcode>();
            videoViewer.SetImageProvider(_imageProvider);
        }

        void buttonConnect_Click(object sender, EventArgs e)
        {
            _webCamera = WebCamera.GetDefaultDevice();

            if (_webCamera != null)
            {
                _connector.Connect(_webCamera, _imageProvider);
                videoViewer.SetImageProvider(_imageProvider);

                videoViewer.Start();

                _webCamera.Start();
                textBoxState.Text = @"USB camera started.";
                buttonStartDetect.Enabled = true;
                buttonConnect.Enabled = false;
                buttonDisconnect.Enabled = true;
            }
            else
                textBoxState.Text = @"USB camera not found.";
        }

        void buttonDisconnect_Click(object sender, EventArgs e)
        {
            if (buttonStopDetect.Enabled)
                StopDetect();

            _connector.Disconnect(_webCamera, _imageProvider);
            videoViewer.Stop();
            _webCamera.Stop();

            textBoxState.Text = @"USB camera stopped.";
            buttonDisconnect.Enabled = false;
            buttonConnect.Enabled = true;
            buttonStartDetect.Enabled = false;
        }


        void buttonStartDetect_Click(object sender, EventArgs e)
        {
            try
            {
                _barcodeReader.Rotation = checkBoxRotate.Checked;
                _barcodeReader.Invert = checkBoxInvert.Checked;
                _barcodeReader.DeeperAnalysis = checkBoxDeeperAnalysis.Checked;
                _barcodeReader.Monochrome = checkBoxMonochrome.Checked;
                _barcodeReader.DetectionOccurred += _barcodeReaderUSBcam_DetectionOccurred;

                _imageProcesserHandler.AddProcesser(_barcodeReader);

                _frameCapture.SetInterval(Int32.Parse(textBoxFrame.Text));

                _connector.Connect(_webCamera, _frameCapture);
                _connector.Connect(_frameCapture, _imageProcesserHandler);

                _frameCapture.Start();

                buttonStartDetect.Enabled = false;
                buttonStopDetect.Enabled = true;
                textBoxDetectorState.Text = @"Running...";
            }
            catch (Exception ex)
            {
                MessageBox.Show(@"Error occured: " + ex.Message);
            }
        }

        void _barcodeReaderUSBcam_DetectionOccurred(object sender, BarcodeDetectedEventArgs e)
        {
            InvokeGuiThread(() =>
            {
                if (e == null)
                    return;

                foreach (var barcode in _barcodesList)
                {
                    if (e.DetectedBarcode.Equals(barcode))
                        return;
                }

                _counter++;

                _barcodesList.Add(e.DetectedBarcode);

                textBoxBarcodes.Text += String.Format("{0}, Date: {1}, Barcode format: {2}, Content: {3}",
                    _counter, DateTime.Now, e.DetectedBarcode.BarcodeFormat, e.DetectedBarcode.Content) + Environment.NewLine;
            });
        }

        void buttonStopDetect_Click(object sender, EventArgs e)
        {
            StopDetect();
        }

        void StopDetect()
        {
            _frameCapture.Stop();
            _connector.Disconnect(_frameCapture, _imageProcesserHandler);
            _barcodeReader.DetectionOccurred -= _barcodeReaderUSBcam_DetectionOccurred;

            buttonStartDetect.Enabled = true;
            buttonStopDetect.Enabled = false;
            textBoxDetectorState.Text = @"Stopped";
        }

        void buttonClear_Click(object sender, EventArgs e)
        {
            _barcodesList.Clear();
            textBoxBarcodes.Text = String.Empty;
            _counter = 0;
        }

        void InvokeGuiThread(Action action)
        {
            BeginInvoke(action);
        }

        void textBoxFrame_TextChanged(object sender, EventArgs e)
        {
            try
            {
                _frameCapture.SetInterval(Int32.Parse(textBoxFrame.Text));
                _frameCapture.Start();
            }
            catch (Exception ex)
            {
            }
        }

        void checkBox_CheckedChanged(object sender, EventArgs e)
        {
            var checkBox = sender as CheckBox;

            if (checkBox == null)
                return;

            if (checkBox.Text == @"Rotate")
                _barcodeReader.Rotation = checkBox.Checked;
            else if (checkBox.Text == @"Invert")
                _barcodeReader.Invert = checkBox.Checked;
            else if (checkBox.Text == @"Deeper Analysis")
                _barcodeReader.DeeperAnalysis = checkBox.Checked;
            else if (checkBox.Text == @"Monochrome")
                _barcodeReader.Monochrome = checkBox.Checked;
        }
    }
}