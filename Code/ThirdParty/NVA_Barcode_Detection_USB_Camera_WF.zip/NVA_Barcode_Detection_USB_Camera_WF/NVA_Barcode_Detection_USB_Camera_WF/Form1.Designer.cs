﻿namespace NVA_Barcode_Detection_USB_Camera_WF
{
    partial class BarcodeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBoxOptions = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBoxFrame = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.checkBoxRotate = new System.Windows.Forms.CheckBox();
            this.checkBoxInvert = new System.Windows.Forms.CheckBox();
            this.checkBoxDeeperAnalysis = new System.Windows.Forms.CheckBox();
            this.checkBoxMonochrome = new System.Windows.Forms.CheckBox();
            this.groupBoxUSBCamera = new System.Windows.Forms.GroupBox();
            this.videoViewer = new Ozeki.Media.Video.Controls.VideoViewerWF();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.buttonStartDetect = new System.Windows.Forms.Button();
            this.textBoxDetectorState = new System.Windows.Forms.TextBox();
            this.buttonStopDetect = new System.Windows.Forms.Button();
            this.textBoxBarcodes = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxState = new System.Windows.Forms.TextBox();
            this.buttonConnect = new System.Windows.Forms.Button();
            this.buttonDisconnect = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.buttonClear = new System.Windows.Forms.Button();
            this.groupBoxOptions.SuspendLayout();
            this.groupBoxUSBCamera.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBoxOptions
            // 
            this.groupBoxOptions.Controls.Add(this.label7);
            this.groupBoxOptions.Controls.Add(this.textBoxFrame);
            this.groupBoxOptions.Controls.Add(this.label6);
            this.groupBoxOptions.Controls.Add(this.checkBoxRotate);
            this.groupBoxOptions.Controls.Add(this.checkBoxInvert);
            this.groupBoxOptions.Controls.Add(this.checkBoxDeeperAnalysis);
            this.groupBoxOptions.Controls.Add(this.checkBoxMonochrome);
            this.groupBoxOptions.Location = new System.Drawing.Point(12, 111);
            this.groupBoxOptions.Name = "groupBoxOptions";
            this.groupBoxOptions.Size = new System.Drawing.Size(238, 107);
            this.groupBoxOptions.TabIndex = 28;
            this.groupBoxOptions.TabStop = false;
            this.groupBoxOptions.Text = "Barcode scanner options";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(133, 76);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(39, 13);
            this.label7.TabIndex = 11;
            this.label7.Text = ". frame";
            // 
            // textBoxFrame
            // 
            this.textBoxFrame.Location = new System.Drawing.Point(104, 73);
            this.textBoxFrame.Name = "textBoxFrame";
            this.textBoxFrame.Size = new System.Drawing.Size(30, 20);
            this.textBoxFrame.TabIndex = 10;
            this.textBoxFrame.Text = "5";
            this.textBoxFrame.TextChanged += new System.EventHandler(this.textBoxFrame_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 76);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(77, 13);
            this.label6.TabIndex = 9;
            this.label6.Text = "Process every:";
            // 
            // checkBoxRotate
            // 
            this.checkBoxRotate.AutoSize = true;
            this.checkBoxRotate.Location = new System.Drawing.Point(9, 20);
            this.checkBoxRotate.Name = "checkBoxRotate";
            this.checkBoxRotate.Size = new System.Drawing.Size(58, 17);
            this.checkBoxRotate.TabIndex = 5;
            this.checkBoxRotate.Text = "Rotate";
            this.checkBoxRotate.UseVisualStyleBackColor = true;
            this.checkBoxRotate.CheckedChanged += new System.EventHandler(this.checkBox_CheckedChanged);
            // 
            // checkBoxInvert
            // 
            this.checkBoxInvert.AutoSize = true;
            this.checkBoxInvert.Location = new System.Drawing.Point(9, 46);
            this.checkBoxInvert.Name = "checkBoxInvert";
            this.checkBoxInvert.Size = new System.Drawing.Size(53, 17);
            this.checkBoxInvert.TabIndex = 7;
            this.checkBoxInvert.Text = "Invert";
            this.checkBoxInvert.UseVisualStyleBackColor = true;
            this.checkBoxInvert.CheckedChanged += new System.EventHandler(this.checkBox_CheckedChanged);
            // 
            // checkBoxDeeperAnalysis
            // 
            this.checkBoxDeeperAnalysis.AutoSize = true;
            this.checkBoxDeeperAnalysis.Location = new System.Drawing.Point(104, 20);
            this.checkBoxDeeperAnalysis.Name = "checkBoxDeeperAnalysis";
            this.checkBoxDeeperAnalysis.Size = new System.Drawing.Size(102, 17);
            this.checkBoxDeeperAnalysis.TabIndex = 6;
            this.checkBoxDeeperAnalysis.Text = "Deeper Analysis";
            this.checkBoxDeeperAnalysis.UseVisualStyleBackColor = true;
            this.checkBoxDeeperAnalysis.CheckedChanged += new System.EventHandler(this.checkBox_CheckedChanged);
            // 
            // checkBoxMonochrome
            // 
            this.checkBoxMonochrome.AutoSize = true;
            this.checkBoxMonochrome.Location = new System.Drawing.Point(104, 45);
            this.checkBoxMonochrome.Name = "checkBoxMonochrome";
            this.checkBoxMonochrome.Size = new System.Drawing.Size(88, 17);
            this.checkBoxMonochrome.TabIndex = 8;
            this.checkBoxMonochrome.Text = "Monochrome";
            this.checkBoxMonochrome.UseVisualStyleBackColor = true;
            this.checkBoxMonochrome.CheckedChanged += new System.EventHandler(this.checkBox_CheckedChanged);
            // 
            // groupBoxUSBCamera
            // 
            this.groupBoxUSBCamera.Controls.Add(this.videoViewer);
            this.groupBoxUSBCamera.Location = new System.Drawing.Point(256, 12);
            this.groupBoxUSBCamera.Name = "groupBoxUSBCamera";
            this.groupBoxUSBCamera.Size = new System.Drawing.Size(453, 290);
            this.groupBoxUSBCamera.TabIndex = 34;
            this.groupBoxUSBCamera.TabStop = false;
            this.groupBoxUSBCamera.Text = "Live USB camera";
            // 
            // videoViewer
            // 
            this.videoViewer.BackColor = System.Drawing.Color.DarkGray;
            this.videoViewer.FlipMode = Ozeki.Media.Video.FlipMode.None;
            this.videoViewer.ForeColor = System.Drawing.Color.DarkGray;
            this.videoViewer.Location = new System.Drawing.Point(18, 19);
            this.videoViewer.Name = "videoViewer";
            this.videoViewer.RotateAngle = 0;
            this.videoViewer.Size = new System.Drawing.Size(416, 264);
            this.videoViewer.TabIndex = 0;
            this.videoViewer.Text = "videoViewerWF3";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.buttonStartDetect);
            this.groupBox2.Controls.Add(this.textBoxDetectorState);
            this.groupBox2.Controls.Add(this.buttonStopDetect);
            this.groupBox2.Location = new System.Drawing.Point(12, 224);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(238, 78);
            this.groupBox2.TabIndex = 32;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Barcode detection";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(9, 54);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(77, 13);
            this.label5.TabIndex = 32;
            this.label5.Text = "Detector state:";
            // 
            // buttonStartDetect
            // 
            this.buttonStartDetect.Enabled = false;
            this.buttonStartDetect.Location = new System.Drawing.Point(6, 19);
            this.buttonStartDetect.Name = "buttonStartDetect";
            this.buttonStartDetect.Size = new System.Drawing.Size(86, 23);
            this.buttonStartDetect.TabIndex = 28;
            this.buttonStartDetect.Text = "Start Detection";
            this.buttonStartDetect.UseVisualStyleBackColor = true;
            this.buttonStartDetect.Click += new System.EventHandler(this.buttonStartDetect_Click);
            // 
            // textBoxDetectorState
            // 
            this.textBoxDetectorState.Enabled = false;
            this.textBoxDetectorState.Location = new System.Drawing.Point(146, 51);
            this.textBoxDetectorState.Name = "textBoxDetectorState";
            this.textBoxDetectorState.ReadOnly = true;
            this.textBoxDetectorState.Size = new System.Drawing.Size(86, 20);
            this.textBoxDetectorState.TabIndex = 31;
            // 
            // buttonStopDetect
            // 
            this.buttonStopDetect.Enabled = false;
            this.buttonStopDetect.Location = new System.Drawing.Point(146, 19);
            this.buttonStopDetect.Name = "buttonStopDetect";
            this.buttonStopDetect.Size = new System.Drawing.Size(86, 23);
            this.buttonStopDetect.TabIndex = 29;
            this.buttonStopDetect.Text = "Stop Detection";
            this.buttonStopDetect.UseVisualStyleBackColor = true;
            this.buttonStopDetect.Click += new System.EventHandler(this.buttonStopDetect_Click);
            // 
            // textBoxBarcodes
            // 
            this.textBoxBarcodes.Location = new System.Drawing.Point(14, 48);
            this.textBoxBarcodes.Multiline = true;
            this.textBoxBarcodes.Name = "textBoxBarcodes";
            this.textBoxBarcodes.Size = new System.Drawing.Size(550, 235);
            this.textBoxBarcodes.TabIndex = 30;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.textBoxState);
            this.groupBox1.Controls.Add(this.buttonConnect);
            this.groupBox1.Controls.Add(this.buttonDisconnect);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(238, 93);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Connect to USB camera";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 68);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 13);
            this.label4.TabIndex = 36;
            this.label4.Text = "Camera state:";
            // 
            // textBoxState
            // 
            this.textBoxState.Enabled = false;
            this.textBoxState.Location = new System.Drawing.Point(87, 65);
            this.textBoxState.Name = "textBoxState";
            this.textBoxState.ReadOnly = true;
            this.textBoxState.Size = new System.Drawing.Size(145, 20);
            this.textBoxState.TabIndex = 35;
            // 
            // buttonConnect
            // 
            this.buttonConnect.Location = new System.Drawing.Point(6, 19);
            this.buttonConnect.Name = "buttonConnect";
            this.buttonConnect.Size = new System.Drawing.Size(86, 23);
            this.buttonConnect.TabIndex = 28;
            this.buttonConnect.Text = "Connect";
            this.buttonConnect.UseVisualStyleBackColor = true;
            this.buttonConnect.Click += new System.EventHandler(this.buttonConnect_Click);
            // 
            // buttonDisconnect
            // 
            this.buttonDisconnect.Enabled = false;
            this.buttonDisconnect.Location = new System.Drawing.Point(146, 19);
            this.buttonDisconnect.Name = "buttonDisconnect";
            this.buttonDisconnect.Size = new System.Drawing.Size(86, 23);
            this.buttonDisconnect.TabIndex = 29;
            this.buttonDisconnect.Text = "Disconnect";
            this.buttonDisconnect.UseVisualStyleBackColor = true;
            this.buttonDisconnect.Click += new System.EventHandler(this.buttonDisconnect_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.buttonClear);
            this.groupBox3.Controls.Add(this.textBoxBarcodes);
            this.groupBox3.Location = new System.Drawing.Point(715, 12);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(580, 290);
            this.groupBox3.TabIndex = 35;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Details of barcodes";
            // 
            // buttonClear
            // 
            this.buttonClear.Location = new System.Drawing.Point(14, 19);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(86, 23);
            this.buttonClear.TabIndex = 31;
            this.buttonClear.Text = "Clear";
            this.buttonClear.UseVisualStyleBackColor = true;
            this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
            // 
            // BarcodeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1310, 315);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBoxUSBCamera);
            this.Controls.Add(this.groupBoxOptions);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.MaximizeBox = false;
            this.Name = "BarcodeForm";
            this.Text = "Barcode Reader";
            this.Load += new System.EventHandler(this.BarcodeForm_Load);
            this.groupBoxOptions.ResumeLayout(false);
            this.groupBoxOptions.PerformLayout();
            this.groupBoxUSBCamera.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxOptions;
        private System.Windows.Forms.CheckBox checkBoxRotate;
        private System.Windows.Forms.CheckBox checkBoxInvert;
        private System.Windows.Forms.CheckBox checkBoxDeeperAnalysis;
        private System.Windows.Forms.CheckBox checkBoxMonochrome;
        private System.Windows.Forms.GroupBox groupBoxUSBCamera;
        private Ozeki.Media.Video.Controls.VideoViewerWF videoViewer;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button buttonStartDetect;
        private System.Windows.Forms.TextBox textBoxDetectorState;
        private System.Windows.Forms.Button buttonStopDetect;
        private System.Windows.Forms.TextBox textBoxBarcodes;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxState;
        private System.Windows.Forms.Button buttonConnect;
        private System.Windows.Forms.Button buttonDisconnect;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBoxFrame;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button buttonClear;
        private System.Windows.Forms.Label label5;
    }
}

