/****************************************************************************
** Meta object code from reading C++ file 'SQLiteViewer.h'
**
** Created: Wed Dec 11 20:17:57 2013
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.4)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../SQLiteViewer.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'SQLiteViewer.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_SQLiteViewer[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      16,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      14,   13,   13,   13, 0x0a,
      27,   13,   13,   13, 0x0a,
      41,   13,   13,   13, 0x0a,
      61,   13,   13,   13, 0x0a,
      81,   13,   13,   13, 0x0a,
     101,   13,   13,   13, 0x0a,
     121,   13,   13,   13, 0x0a,
     140,   13,   13,   13, 0x0a,
     159,   13,   13,   13, 0x0a,
     184,  178,   13,   13, 0x0a,
     211,   13,   13,   13, 0x0a,
     231,   13,   13,   13, 0x0a,
     254,   13,   13,   13, 0x0a,
     281,   13,   13,   13, 0x0a,
     306,   13,   13,   13, 0x0a,
     335,  178,   13,   13, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_SQLiteViewer[] = {
    "SQLiteViewer\0\0OnFileOpen()\0OnFileClose()\0"
    "OnShowTable_Click()\0OnHideTable_Click()\0"
    "OnUpdateAll_Click()\0OnCommitAll_Click()\0"
    "OnCreateDemoDB01()\0OnCreateDemoDB02()\0"
    "OnCreateDemoDB03()\0index\0"
    "OnSelectTable(QModelIndex)\0"
    "OnAddRecord_Click()\0OnDeleteRecord_Click()\0"
    "OnDeleteAllRecords_Click()\0"
    "OnUnDeleteRecord_Click()\0"
    "OnUnDeleteAllRecords_Click()\0"
    "OnEditField_DoubleClick(QModelIndex)\0"
};

void SQLiteViewer::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        SQLiteViewer *_t = static_cast<SQLiteViewer *>(_o);
        switch (_id) {
        case 0: _t->OnFileOpen(); break;
        case 1: _t->OnFileClose(); break;
        case 2: _t->OnShowTable_Click(); break;
        case 3: _t->OnHideTable_Click(); break;
        case 4: _t->OnUpdateAll_Click(); break;
        case 5: _t->OnCommitAll_Click(); break;
        case 6: _t->OnCreateDemoDB01(); break;
        case 7: _t->OnCreateDemoDB02(); break;
        case 8: _t->OnCreateDemoDB03(); break;
        case 9: _t->OnSelectTable((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 10: _t->OnAddRecord_Click(); break;
        case 11: _t->OnDeleteRecord_Click(); break;
        case 12: _t->OnDeleteAllRecords_Click(); break;
        case 13: _t->OnUnDeleteRecord_Click(); break;
        case 14: _t->OnUnDeleteAllRecords_Click(); break;
        case 15: _t->OnEditField_DoubleClick((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData SQLiteViewer::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject SQLiteViewer::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_SQLiteViewer,
      qt_meta_data_SQLiteViewer, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &SQLiteViewer::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *SQLiteViewer::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *SQLiteViewer::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_SQLiteViewer))
        return static_cast<void*>(const_cast< SQLiteViewer*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int SQLiteViewer::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 16)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 16;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
