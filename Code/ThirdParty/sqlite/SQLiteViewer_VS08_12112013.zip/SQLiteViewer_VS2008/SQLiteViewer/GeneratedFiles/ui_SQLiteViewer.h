/********************************************************************************
** Form generated from reading UI file 'SQLiteViewer.ui'
**
** Created: Wed Dec 11 21:02:31 2013
**      by: Qt User Interface Compiler version 4.8.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SQLITEVIEWER_H
#define UI_SQLITEVIEWER_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QListView>
#include <QtGui/QMainWindow>
#include <QtGui/QMenu>
#include <QtGui/QMenuBar>
#include <QtGui/QPushButton>
#include <QtGui/QStatusBar>
#include <QtGui/QTableView>
#include <QtGui/QToolBar>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_SQLiteViewerClass
{
public:
    QAction *actionOpen_DB;
    QAction *actionClose_DB;
    QAction *actionCreate_DemoDB01;
    QAction *actionCreate_DemoDB02;
    QAction *actionCreate_DemoDB03;
    QWidget *centralWidget;
    QListView *lstTableNames;
    QPushButton *cmdShowTable;
    QTableView *tblRecords;
    QPushButton *cmdUpdateAll;
    QPushButton *cmdCommitAll;
    QPushButton *cmdAddRecord;
    QPushButton *cmdDeleteRecord;
    QPushButton *cmdDeleteAllRecords;
    QPushButton *cmdUnDeleteRecord;
    QPushButton *cmdUnDeleteAllRecords;
    QPushButton *cmdHideTable;
    QPushButton *cmdUndoRevert;
    QLabel *lblTableNames;
    QLabel *lblDataNames;
    QMenuBar *menuBar;
    QMenu *menuFile;
    QMenu *menuDemo;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *SQLiteViewerClass)
    {
        if (SQLiteViewerClass->objectName().isEmpty())
            SQLiteViewerClass->setObjectName(QString::fromUtf8("SQLiteViewerClass"));
        SQLiteViewerClass->resize(1178, 800);
        actionOpen_DB = new QAction(SQLiteViewerClass);
        actionOpen_DB->setObjectName(QString::fromUtf8("actionOpen_DB"));
        actionClose_DB = new QAction(SQLiteViewerClass);
        actionClose_DB->setObjectName(QString::fromUtf8("actionClose_DB"));
        actionCreate_DemoDB01 = new QAction(SQLiteViewerClass);
        actionCreate_DemoDB01->setObjectName(QString::fromUtf8("actionCreate_DemoDB01"));
        actionCreate_DemoDB02 = new QAction(SQLiteViewerClass);
        actionCreate_DemoDB02->setObjectName(QString::fromUtf8("actionCreate_DemoDB02"));
        actionCreate_DemoDB03 = new QAction(SQLiteViewerClass);
        actionCreate_DemoDB03->setObjectName(QString::fromUtf8("actionCreate_DemoDB03"));
        centralWidget = new QWidget(SQLiteViewerClass);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        lstTableNames = new QListView(centralWidget);
        lstTableNames->setObjectName(QString::fromUtf8("lstTableNames"));
        lstTableNames->setGeometry(QRect(10, 60, 221, 481));
        cmdShowTable = new QPushButton(centralWidget);
        cmdShowTable->setObjectName(QString::fromUtf8("cmdShowTable"));
        cmdShowTable->setGeometry(QRect(140, 540, 93, 28));
        tblRecords = new QTableView(centralWidget);
        tblRecords->setObjectName(QString::fromUtf8("tblRecords"));
        tblRecords->setGeometry(QRect(260, 60, 901, 641));
        tblRecords->horizontalHeader()->setVisible(true);
        cmdUpdateAll = new QPushButton(centralWidget);
        cmdUpdateAll->setObjectName(QString::fromUtf8("cmdUpdateAll"));
        cmdUpdateAll->setGeometry(QRect(260, 700, 93, 28));
        cmdCommitAll = new QPushButton(centralWidget);
        cmdCommitAll->setObjectName(QString::fromUtf8("cmdCommitAll"));
        cmdCommitAll->setGeometry(QRect(370, 700, 93, 28));
        cmdAddRecord = new QPushButton(centralWidget);
        cmdAddRecord->setObjectName(QString::fromUtf8("cmdAddRecord"));
        cmdAddRecord->setGeometry(QRect(790, 30, 93, 28));
        cmdDeleteRecord = new QPushButton(centralWidget);
        cmdDeleteRecord->setObjectName(QString::fromUtf8("cmdDeleteRecord"));
        cmdDeleteRecord->setGeometry(QRect(900, 0, 93, 28));
        cmdDeleteAllRecords = new QPushButton(centralWidget);
        cmdDeleteAllRecords->setObjectName(QString::fromUtf8("cmdDeleteAllRecords"));
        cmdDeleteAllRecords->setGeometry(QRect(1030, 0, 111, 28));
        cmdUnDeleteRecord = new QPushButton(centralWidget);
        cmdUnDeleteRecord->setObjectName(QString::fromUtf8("cmdUnDeleteRecord"));
        cmdUnDeleteRecord->setGeometry(QRect(900, 30, 121, 28));
        cmdUnDeleteAllRecords = new QPushButton(centralWidget);
        cmdUnDeleteAllRecords->setObjectName(QString::fromUtf8("cmdUnDeleteAllRecords"));
        cmdUnDeleteAllRecords->setGeometry(QRect(1030, 30, 131, 28));
        cmdHideTable = new QPushButton(centralWidget);
        cmdHideTable->setObjectName(QString::fromUtf8("cmdHideTable"));
        cmdHideTable->setGeometry(QRect(140, 570, 93, 28));
        cmdUndoRevert = new QPushButton(centralWidget);
        cmdUndoRevert->setObjectName(QString::fromUtf8("cmdUndoRevert"));
        cmdUndoRevert->setGeometry(QRect(470, 700, 93, 28));
        lblTableNames = new QLabel(centralWidget);
        lblTableNames->setObjectName(QString::fromUtf8("lblTableNames"));
        lblTableNames->setGeometry(QRect(10, 40, 53, 16));
        lblDataNames = new QLabel(centralWidget);
        lblDataNames->setObjectName(QString::fromUtf8("lblDataNames"));
        lblDataNames->setGeometry(QRect(260, 40, 53, 16));
        SQLiteViewerClass->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(SQLiteViewerClass);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 1178, 26));
        menuFile = new QMenu(menuBar);
        menuFile->setObjectName(QString::fromUtf8("menuFile"));
        menuDemo = new QMenu(menuBar);
        menuDemo->setObjectName(QString::fromUtf8("menuDemo"));
        SQLiteViewerClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(SQLiteViewerClass);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        SQLiteViewerClass->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(SQLiteViewerClass);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        SQLiteViewerClass->setStatusBar(statusBar);

        menuBar->addAction(menuFile->menuAction());
        menuBar->addAction(menuDemo->menuAction());
        menuFile->addAction(actionOpen_DB);
        menuFile->addAction(actionClose_DB);
        menuDemo->addAction(actionCreate_DemoDB01);
        menuDemo->addAction(actionCreate_DemoDB02);
        menuDemo->addAction(actionCreate_DemoDB03);

        retranslateUi(SQLiteViewerClass);

        QMetaObject::connectSlotsByName(SQLiteViewerClass);
    } // setupUi

    void retranslateUi(QMainWindow *SQLiteViewerClass)
    {
        SQLiteViewerClass->setWindowTitle(QApplication::translate("SQLiteViewerClass", "SQLiteViewer", 0, QApplication::UnicodeUTF8));
        actionOpen_DB->setText(QApplication::translate("SQLiteViewerClass", "Open DB", 0, QApplication::UnicodeUTF8));
        actionClose_DB->setText(QApplication::translate("SQLiteViewerClass", "Close DB", 0, QApplication::UnicodeUTF8));
        actionCreate_DemoDB01->setText(QApplication::translate("SQLiteViewerClass", "Create DemoDB01", 0, QApplication::UnicodeUTF8));
        actionCreate_DemoDB02->setText(QApplication::translate("SQLiteViewerClass", "Create DemoDB02", 0, QApplication::UnicodeUTF8));
        actionCreate_DemoDB03->setText(QApplication::translate("SQLiteViewerClass", "Create DemoDB03", 0, QApplication::UnicodeUTF8));
        cmdShowTable->setText(QApplication::translate("SQLiteViewerClass", "SHOW Table", 0, QApplication::UnicodeUTF8));
        cmdUpdateAll->setText(QApplication::translate("SQLiteViewerClass", "Update All", 0, QApplication::UnicodeUTF8));
        cmdCommitAll->setText(QApplication::translate("SQLiteViewerClass", "Commit All", 0, QApplication::UnicodeUTF8));
        cmdAddRecord->setText(QApplication::translate("SQLiteViewerClass", "Add Record", 0, QApplication::UnicodeUTF8));
        cmdDeleteRecord->setText(QApplication::translate("SQLiteViewerClass", "Delete Record", 0, QApplication::UnicodeUTF8));
        cmdDeleteAllRecords->setText(QApplication::translate("SQLiteViewerClass", "Delete All Records", 0, QApplication::UnicodeUTF8));
        cmdUnDeleteRecord->setText(QApplication::translate("SQLiteViewerClass", "UNDelete Record", 0, QApplication::UnicodeUTF8));
        cmdUnDeleteAllRecords->setText(QApplication::translate("SQLiteViewerClass", "UNDelete All Records", 0, QApplication::UnicodeUTF8));
        cmdHideTable->setText(QApplication::translate("SQLiteViewerClass", "HIDE Table", 0, QApplication::UnicodeUTF8));
        cmdUndoRevert->setText(QApplication::translate("SQLiteViewerClass", "Undo Revert", 0, QApplication::UnicodeUTF8));
        lblTableNames->setText(QApplication::translate("SQLiteViewerClass", "TABLES", 0, QApplication::UnicodeUTF8));
        lblDataNames->setText(QApplication::translate("SQLiteViewerClass", "DATA", 0, QApplication::UnicodeUTF8));
        menuFile->setTitle(QApplication::translate("SQLiteViewerClass", "File", 0, QApplication::UnicodeUTF8));
        menuDemo->setTitle(QApplication::translate("SQLiteViewerClass", "Demo", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class SQLiteViewerClass: public Ui_SQLiteViewerClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SQLITEVIEWER_H
