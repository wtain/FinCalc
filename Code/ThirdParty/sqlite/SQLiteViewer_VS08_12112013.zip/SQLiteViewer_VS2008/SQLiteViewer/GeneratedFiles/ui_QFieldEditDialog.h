/********************************************************************************
** Form generated from reading UI file 'QFieldEditDialog.ui'
**
** Created: Wed Dec 11 21:02:31 2013
**      by: Qt User Interface Compiler version 4.8.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_QFIELDEDITDIALOG_H
#define UI_QFIELDEDITDIALOG_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHeaderView>
#include <QtGui/QPushButton>
#include <QtGui/QTextEdit>

QT_BEGIN_NAMESPACE

class Ui_QFieldEditDialogClass
{
public:
    QPushButton *cmdOK;
    QPushButton *cmdCancel;
    QTextEdit *txtField;

    void setupUi(QDialog *QFieldEditDialogClass)
    {
        if (QFieldEditDialogClass->objectName().isEmpty())
            QFieldEditDialogClass->setObjectName(QString::fromUtf8("QFieldEditDialogClass"));
        QFieldEditDialogClass->resize(700, 400);
        cmdOK = new QPushButton(QFieldEditDialogClass);
        cmdOK->setObjectName(QString::fromUtf8("cmdOK"));
        cmdOK->setGeometry(QRect(490, 360, 93, 28));
        cmdCancel = new QPushButton(QFieldEditDialogClass);
        cmdCancel->setObjectName(QString::fromUtf8("cmdCancel"));
        cmdCancel->setGeometry(QRect(600, 360, 93, 28));
        txtField = new QTextEdit(QFieldEditDialogClass);
        txtField->setObjectName(QString::fromUtf8("txtField"));
        txtField->setGeometry(QRect(10, 10, 680, 340));

        retranslateUi(QFieldEditDialogClass);

        QMetaObject::connectSlotsByName(QFieldEditDialogClass);
    } // setupUi

    void retranslateUi(QDialog *QFieldEditDialogClass)
    {
        QFieldEditDialogClass->setWindowTitle(QApplication::translate("QFieldEditDialogClass", "QFieldEditDialog", 0, QApplication::UnicodeUTF8));
        cmdOK->setText(QApplication::translate("QFieldEditDialogClass", "OK", 0, QApplication::UnicodeUTF8));
        cmdCancel->setText(QApplication::translate("QFieldEditDialogClass", "CANCEL", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class QFieldEditDialogClass: public Ui_QFieldEditDialogClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_QFIELDEDITDIALOG_H
